class BaseController extends Controller {

    /**
     * Class constructor.
     * @access public
     */
    constructor() {
        super();
    }
}
