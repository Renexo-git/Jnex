class BaseController extends Controller {

    /**
     * Class constructor.
     * @access public
     */
    constructor() {
        super();
    }
}
module.exports = BaseController;
