include("BaseController.js");

class MyController extends BaseController {

    /**
     * Class constructor.
     * @access public
     */
    constructor() {
        super();
    }
}
