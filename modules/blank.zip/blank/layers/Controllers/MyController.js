const BaseController = require("./BaseController");

class MyController extends BaseController {

    /**
     * Class constructor.
     * @access public
     */
    constructor() {
        super();
    }
}
module.exports = MyController;
