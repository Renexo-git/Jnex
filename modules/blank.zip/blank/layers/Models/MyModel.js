class MyModel extends Model {

    /**
     * Class constructor.
     * @access public
     */
    constructor() {
        super();
    }
}
